@if($slot != "")
    <h6><b>{{ $label}}</b></h6>
    <p class="lead">{{ $slot }}</p>
    <hr>
@endif