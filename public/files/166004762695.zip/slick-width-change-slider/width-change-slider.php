<?php

/**
 * Elementor Card Slider Plugin
 *
 * @package ElementorGrid
 *
 * Plugin Name: Specialized Program Slider
 * Description: Simple Elementor width change slider
 * Plugin URI:  http://farjad.42web.io/
 * Version:     1.0.0
 * Author:      Farjad Akbar
 * Author URI:  https://www.fiverr.com/farjadakbar?public_mode=true
 * Text Domain: width-change-slider
 */


if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register oEmbed Widget.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */

function specialized_program()
{
    register_post_type(
        'Programs',
        // CPT Options
        array(
            'labels' => array(
                'name' => __('Programs'),
                'singular_name' => __('Programs')
            ),
            'public' => true,
            'has_archive' => true,
            // 'rewrite' => array('slug' => 'mui-programs'),
            'supports' => array('title', 'editor', 'thumbnail')
        )
    );
}
// Hooking up our function to theme setup
add_action('init', 'specialized_program');

require_once(__DIR__ . '/inc/multiimage.php');
function register_muislider_widget($widgets_manager)
{
    require_once(__DIR__ . '/widget/custom-elementor-widget.php');
    $widgets_manager->register(new \Elementor_Slider_Widget());
}
add_action('elementor/widgets/register', 'register_muislider_widget');