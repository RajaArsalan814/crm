<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor Porfolio Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_Slider_Widget extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Porfolio widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */

    public function __construct($data = array(), $args = null)
    {
        parent::__construct($data, $args);

        wp_enqueue_style('mui_out_style', plugins_url('../assets/slick.css', __FILE__), '', '1.0');
        wp_enqueue_style('mui_style', plugins_url('../assets/style.css', __FILE__), '', '1.0');

        wp_register_script('mui_out_script', plugins_url('../assets/slick.js', __FILE__), array('jquery'));
        wp_register_script('mui_script', plugins_url('../assets/main.js', __FILE__), array('jquery'));

        wp_enqueue_script('mui_out_script');
        wp_enqueue_script('mui_script');
    }
    public function get_name()
    {
        return 'Mui Slider';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title()
    {
        return esc_html__('Slider', 'width-change-slider');
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-code';
    }

    /**
     * Get custom help URL.
     *
     * Retrieve a URL where the user can get more information about the widget.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget help URL.
     */
    public function get_custom_help_url()
    {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['general'];
    }

    /**
     * Get widget keywords.
     *
     * Retrieve the list of keywords the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget keywords.
     */
    public function get_keywords()
    {
        return ['slider', 'card', 'mui'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */


    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'width-change-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'main_heading',
            [
                'label' => esc_html__('Main Heading', 'width-change-slider'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'input_type' => 'text',
                'placeholder' => esc_html__('Specialized programs', 'width-change-slider'),
                'default' => esc_html__('Specialized programs', 'width-change-slider'),
            ]
        );

        $this->add_control(
            'sub_heading',
            [
                'label' => esc_html__('Sub Heading', 'width-change-slider'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'input_type' => 'text',
                'placeholder' => esc_html__('Specialized programs', 'width-change-slider'),
                'default' => esc_html__('Find the perfect short-term training program for your goals.', 'width-change-slider'),
            ]
        );

        $this->add_control(
            'mui_button',
            [
                'label' => esc_html__('Button', 'width-change-slider'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'input_type' => 'text',
                'placeholder' => esc_html__('Learn More', 'width-change-slider'),
                'default' => esc_html__('Learn More', 'width-change-slider'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'general_section',
            [
                'label' => __('General', 'width-change-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'mui_main_heading',
                'label' => __('Heading', 'width-change-slider'),
                'scheme' => Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .muiheading h2',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'mui_sub_heading',
                'label' => __('Sub Heading', 'width-change-slider'),
                'scheme' => Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .muiheading h3',
            ]
        );

        $this->add_control(
            'mui_main_heading_color',
            [
                'label' => esc_html__('Heading Color', 'width-change-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .muiheading h2' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'mui_sub_heading_color',
            [
                'label' => esc_html__('Sub Heading Color', 'width-change-slider'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .muiheading h3' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'muibutton_section',
            [
                'label' => __('Button', 'width-change-slider'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'mui_button_typography',
                'label' => __('Typography', 'width-change-slider'),
                'scheme' => Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .MuiBox .MuiButtonBase',
            ]
        );
        $this->add_control(
            'mui_button_width',
            [
                'label' => esc_html__('Width', 'width-change-slider'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .MuiButtonBase' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mui_button_padding',
            [
                'label' => esc_html__('Padding', 'width-change-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}}  .MuiBox .MuiButtonBase' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mui_button_margin',
            [
                'label' => esc_html__('Margin', 'width-change-slider'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}}  .MuiBox .MuiButtonBase' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {

        $settings = $this->get_settings_for_display();

        $pag = 9999999999999;

        // if ($settings["show_pagination"] != '') {
        //     $pag = $settings['items'];
        // }
        $args = array(
            'post_type' => 'programs',
            'post_status' => 'publish',
            'posts_per_page' => $pag,
            'orderby' => 'title',
            'order' => 'DESC',
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
            // 'cat' => 'home',
        );

        $loop = new WP_Query($args);
?>
<div class="container">
    <div class="muiheading">
        <h2><?php echo $settings['main_heading']; ?></h2>
        <h3><?php echo $settings['sub_heading']; ?></h3>
    </div>
</div>
<div class="carousel">
    <?php
            // if (have_posts()) :
            while ($loop->have_posts()) : $loop->the_post();
                $id = $loop->ID;
                $featured_img = get_the_post_thumbnail_url($id);
                // $mobil_thumb_id = 
                $mobile_thumb_url = MultiPostThumbnails::get_the_post_thumbnail('programs', 'secondary-image', $id);
                // $mobile_thumb_url = wp_get_attachment_url($mobil_thumb_id);
                // MultiPostThumbnails::the_post_thumbnail('programs', 'secondary-image');
                // echo $mobil_thumb_id;
            ?>

    <div class="MuiBox" data-desktopsrc="<?php echo $featured_img ?>" data-mobilesrc="<?php echo $mobile_thumb_url ?>">
 
        <div class="MuiPaper">
            <div class="MuiCardContent">
                <div class="MuiBoxInner" expanded="1">
                    <div class="MuiBoxImage">
                        <img src="<?php echo (get_custom_logo()) ? get_custom_logo() : 'https://web-cdn.centr.com/deploy/static/images/programs/power/logo.svg?v=1'; ?>"
                            title="power" alt="power" style="height: 100%; width: 100%;">
                    </div>
                    <div class="MuiBoxText">
                        <p class="MuiBoxPara" pb="2"><?php echo wp_trim_words(get_the_content(), 30, ''); ?></p>
                        <a href="<?php echo get_permalink(); ?>" class=" MuiButtonBase" tabindex="0" type="button"
                            shadow="0" style="opacity: 1; transition: opacity 225ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;">
                            <span class="MuiButton-label"><?php echo $settings['mui_button']; ?></span><span
                                class="MuiTouchRipple"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php endwhile; ?>

</div>

<?php

    }
}