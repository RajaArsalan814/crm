jQuery(document).ready(function ($) {
    $('.carousel').slick({
            infinite: true,
            lazyLoad: 'progressive',
            speed: 300,
            slidesToShow: 3,
            variableWidth: true,
            adaptiveHeight: true,
            prevArrow: '<button class="MuiIcon prev"><span class="MuiIconstyles"><svg class="MuiSvgIcon-root"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></svg></span></button>',
            nextArrow: '<button class="MuiIcon next"><span class="MuiIconstyles" ><svg class="MuiSvgIcon-root"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></svg></span></button>'
        });
    
    setTimeout(() => {
        // console.log($('.carousel'));
        $('.carousel').slick({
            infinite: true,
            lazyLoad: 'progressive',
            speed: 300,
            slidesToShow: 3,
            variableWidth: true,
            adaptiveHeight: true,
            prevArrow: '<button class="MuiIcon prev"><span class="MuiIconstyles"><svg class="MuiSvgIcon-root"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></svg></span></button>',
            nextArrow: '<button class="MuiIcon next"><span class="MuiIconstyles" ><svg class="MuiSvgIcon-root"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></svg></span></button>'
        });
    }, 5000);

    setInterval(() => {
        var muibox = document.querySelectorAll(".MuiBox");
        for (var i = 0; i < muibox.length; i++) {
            var mui = muibox[i];
            // var ele = ".MuiBox .MuiPaper";
            // console.log(muibox[i]);

            if (window.matchMedia('(min-width: 1100px)').matches) {
                dskSrc = mui.getAttribute('data-desktopsrc');
                if ($(mui).hasClass("slick-current")) {
                    $(mui).children(".MuiPaper").css({
                        'background': 'url(' + dskSrc + ')',
                        'background-size': 'cover',
                        'background-repeat': 'no-repeat',
                        'background-position': 'center center',
                    });
                } else {
                    mobileSrc = mui.getAttribute('data-mobilesrc');
                    $(mui).children(".MuiPaper").css({
                        'background': 'url(' + mobileSrc + ')',
                        'background-size': 'cover',
                        'background-repeat': 'no-repeat',
                        'background-position': 'center center',
                    });
                }

            }
            else {
                mobileSrc = mui.getAttribute('data-mobilesrc');
                $(mui).children(".MuiPaper").css({
                    'background': 'url(' + mobileSrc + ')',
                    'background-size': 'cover',
                    'background-repeat': 'no-repeat',
                    'background-position': 'center center',
                });
            }
        }
    }, 1000);
});